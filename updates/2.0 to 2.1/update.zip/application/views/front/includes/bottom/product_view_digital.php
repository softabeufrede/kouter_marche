
        

        <!-- JS Page Level -->
        <script src="<?php echo base_url(); ?>template/front/js/share/jquery.share.js"></script>
		<script src="<?php echo base_url(); ?>template/front/plugins/owl-carousel2/owl.carousel.min.js"></script>